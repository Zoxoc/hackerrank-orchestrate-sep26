# Token usage and cost report — final full-dataset run

Run: `python3 code/main.py` → 250/250 rows in `output.csv` (~1 s cached).

## Engine

The agent is fully rule-based and deterministic. It makes **zero calls to any
language model or paid API**. All reasoning (state reconstruction, forecast,
message rules, decisions) is local Python; the only ML component is a local
ONNX OCR reader for bill photos (runs on CPU, no API, no tokens).

## Model providers and names

| Component | Provider | Model | Calls |
|---|---|---|---|
| Decision engine (`financial_state`, `forecast`, `message_actions`, `decision`) | none (local code) | n/a | 0 |
| Photo reader (`ocr_amounts`) | none (local) | PP-OCRv4 detection + recognition + orientation classifier (vendored ONNX in `code/ocr_models/`, pinned via `code/requirements.txt`: `rapidocr-onnxruntime==1.4.4`) | 11 image reads (lazy, per-request; results cached by file hash in `code/ocr_cache.json`) |

## Token accounting (LLM API)

| Metric | Value |
|---|---|
| Model providers used | none |
| Model calls | 0 |
| Input tokens | 0 |
| Output tokens | 0 |
| Total tokens | 0 |
| Average tokens per request (÷250) | 0 |
| Estimated total cost | $0.00 |
| Estimated cost per request | $0.00 |

## Local compute (informational, not billed)

- Full 250-request run: ~1 s with warm OCR cache; ~40–60 s cold (one-time ~4 s
  per never-seen photo, then cached).
- OCR cache hits: 250/250 decisions reproducible byte-identically on re-run.
- No credentials, API keys, or sensitive configuration are used or stored.
